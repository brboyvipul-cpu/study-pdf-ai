# ChemStudy PDF Maker – Android Studio Source

## શું કરે છે?
- Question Paper PDF અને Notes PDF પસંદ કરે છે.
- PDF માં રહેલા selectable text ને વાંચે છે.
- Question lines ઓળખવાનો પ્રયત્ન કરે છે.
- Notes માં પ્રશ્ન સાથે સૌથી વધુ મેળ ખાતા paragraph શોધે છે.
- મળેલા લખાણનું preview બતાવે છે અને Answer PDF બનાવે છે.

## Android Studio માં ચલાવવાની રીત
1. Android Studio ખોલો.
2. `Open` પસંદ કરીને આ project folder પસંદ કરો.
3. Gradle Sync પૂરો થવા દો.
4. Android phone માં USB debugging ચાલુ કરીને Run દબાવો, અથવા emulator પસંદ કરો.

## મહત્વની મર્યાદાઓ
- આ પ્રથમ MVP છે; OCR નથી. સ્કેન કરેલી/image-only PDF માંથી text નહીં મળે.
- Question detection અને matching keyword આધારિત છે; દરેક પ્રશ્નનો સાચો જવાબ મળ્યો જ હોય તેની ખાતરી નથી.
- Notes માંથી મળેલા paragraph જ ઉમેરાય છે; AI દ્વારા નવા facts બનાવાતા નથી.
- ગુજરાતી PDF લખાણનું દેખાવ Android/device font પર આધારિત હોઈ શકે છે. અલગ Gujarati font embed કરવાનું આગામી version માં ઉમેરવું યોગ્ય છે.
- PDF exports app-specific storage માં બને છે અને PDF viewer ઉપલબ્ધ હોય તો ખુલે છે.

## આગળ ઉમેરવા યોગ્ય સુવિધાઓ
- OCR (સ્કેન કરેલી Notes માટે)
- Unit-wise filtering
- Gujarati answer editing
- Paragraph relevance tuning
- Share / Save As action
