package com.chemstudy.pdfmaker

import android.app.Activity
import android.content.Intent
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import kotlin.math.max

class MainActivity : Activity() {
    private val pickQuestion = 101
    private val pickNotes = 102
    private var questionText = ""
    private var notesText = ""
    private var questionName = ""
    private var notesName = ""
    private lateinit var status: TextView
    private lateinit var preview: TextView
    private lateinit var makeButton: Button
    private var answerDraft = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 24)
            setBackgroundColor(Color.rgb(247, 249, 252))
        }
        val title = TextView(this).apply {
            text = "⚗ ChemStudy PDF Maker"
            textSize = 24f; setTextColor(Color.rgb(25, 74, 125))
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(title)
        root.addView(label("તમારી Notes માંથી Question ના જવાબ શોધો"))
        root.addView(button("1. Question Paper PDF પસંદ કરો") { openPicker(pickQuestion) })
        root.addView(button("2. Notes PDF પસંદ કરો") { openPicker(pickNotes) })
        root.addView(button("3. જવાબ શોધો અને Preview જુઓ") { createAnswers() })
        makeButton = button("4. Answer PDF બનાવો") { exportPdf() }
        makeButton.isEnabled = false
        root.addView(makeButton)
        status = label("હજુ કોઈ PDF પસંદ કરેલી નથી.")
        root.addView(status)
        val scroll = ScrollView(this)
        preview = TextView(this).apply {
            textSize = 15f; setTextColor(Color.DKGRAY)
            setPadding(14, 14, 14, 14)
            setBackgroundColor(Color.WHITE)
        }
        scroll.addView(preview)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun label(s: String) = TextView(this).apply {
        text = s; textSize = 15f; setTextColor(Color.DKGRAY)
        setPadding(0, 14, 0, 14)
    }

    private fun button(s: String, action: () -> Unit) = Button(this).apply {
        text = s; isAllCaps = false
        setOnClickListener { action() }
    }

    private fun openPicker(code: Int) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/pdf"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivityForResult(intent, code)
    }

    @Deprecated("Use Activity Result APIs in a production update")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val text = extractPdfText(uri)
            if (text.isBlank()) {
                status.text = "આ PDF માંથી selectable text મળ્યું નથી. કદાચ તે scanned/image PDF છે."
                return
            }
            if (requestCode == pickQuestion) {
                questionText = text
                questionName = displayName(uri)
            } else if (requestCode == pickNotes) {
                notesText = text
                notesName = displayName(uri)
            }
            status.text = "Question: ${if(questionText.isNotBlank()) questionName else "પસંદ નથી"}\nNotes: ${if(notesText.isNotBlank()) notesName else "પસંદ નથી"}"
        } catch (e: Exception) {
            status.text = "PDF વાંચવામાં ભૂલ: ${e.message}"
        }
    }

    private fun displayName(uri: Uri): String =
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && idx >= 0) c.getString(idx) else "PDF"
        } ?: "PDF"

    private fun extractPdfText(uri: Uri): String {
        val input = contentResolver.openInputStream(uri) ?: error("ફાઇલ ખોલી શકાઈ નથી")
        input.use {
            val doc = PDDocument.load(it)
            doc.use { pdf -> return PDFTextStripper().getText(pdf) }
        }
    }

    private fun createAnswers() {
        if (questionText.isBlank() || notesText.isBlank()) {
            status.text = "પહેલા Question Paper અને Notes PDF બંને પસંદ કરો."
            return
        }
        val questions = splitQuestions(questionText)
        if (questions.isEmpty()) {
            status.text = "Question ઓળખી શકાયા નથી. Question PDF માં selectable text હોવું જોઈએ."
            return
        }
        val paragraphs = notesText.replace('\r', '\n')
            .split(Regex("\\n\\s*\\n|(?<=[.!?])\\s+(?=[A-Z0-9])"))
            .map { it.trim().replace(Regex("\\s+"), " ") }
            .filter { it.length > 35 }

        val out = StringBuilder()
        out.append("ChemStudy PDF Maker\\n")
        out.append("Notes source: $notesName\\n\\n")
        questions.forEachIndexed { index, q ->
            val ranked = paragraphs.map { p -> p to similarity(q, p) }
                .filter { it.second > 0 }
                .sortedByDescending { it.second }
                .take(4)
            out.append("પ્રશ્ન ${index + 1}: $q\\n")
            if (ranked.isEmpty()) {
                out.append("જવાબ: તમારી Notes PDF માં આ પ્રશ્ન માટે સ્પષ્ટ મેળ ખાતી માહિતી મળી નથી. Notes માં સંબંધિત Unit/Topic તપાસો.\\n")
            } else {
                out.append("જવાબ (Notes માંથી મળેલી માહિતી):\\n")
                ranked.forEach { (p, _) -> out.append("• $p\\n") }
                out.append("નોંધ: આ જવાબ Notes ના સંબંધિત લખાણમાંથી ગોઠવાયો છે; પરીક્ષા પહેલાં મૂળ Notes સાથે ચકાસો.\\n")
            }
            out.append("\\n")
        }
        answerDraft = out.toString()
        preview.text = answerDraft
        makeButton.isEnabled = true
        status.text = "${questions.size} પ્રશ્નો મળ્યા. જવાબો Notes માંથી શોધવામાં આવ્યા."
    }

    private fun splitQuestions(text: String): List<String> {
        val lines = text.lines().map { it.trim() }.filter { it.isNotBlank() }
        val result = mutableListOf<String>()
        val current = StringBuilder()
        val starts = Regex("""^(?:Q(?:uestion)?\.?\s*)?\d{1,2}\s*[\).:-]\s*|^[૦-૯]{1,2}\s*[\).:-]\s*""", RegexOption.IGNORE_CASE)
        for (line in lines) {
            val isQuestion = starts.containsMatchIn(line) ||
                line.startsWith("Define ", true) ||
                line.startsWith("Explain ", true) ||
                line.startsWith("Discuss ", true) ||
                line.startsWith("What ", true) ||
                line.startsWith("કયો") || line.startsWith("સમજાવો") || line.startsWith("વ્યાખ્યા")
            if (isQuestion && current.isNotEmpty()) {
                result.add(current.toString().trim()); current.clear()
            }
            if (isQuestion || current.isNotEmpty()) current.append(line).append(' ')
        }
        if (current.isNotEmpty()) result.add(current.toString().trim())
        return result.filter { it.length > 8 }.take(100)
    }

    private fun tokens(s: String): Set<String> =
        Regex("[\\p{L}\\p{N}]{3,}").findAll(s.lowercase(Locale.ROOT))
            .map { it.value }.filter { it !in stopWords }.toSet()

    private fun similarity(q: String, p: String): Int {
        val qt = tokens(q); val pt = tokens(p)
        if (qt.isEmpty() || pt.isEmpty()) return 0
        return qt.intersect(pt).size * 100 / max(1, qt.size)
    }

    private val stopWords = setOf("the","and","for","what","with","from","that","this","are","was","were","how","explain","discuss","define","ની","ના","અને","છે","શું","કરો","માટે","એક","આ")

    private fun exportPdf() {
        if (answerDraft.isBlank()) return
        try {
            val doc = PdfDocument()
            val pageW = 595
            val pageH = 842
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.BLACK; textSize = 12f
                typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            }
            val headingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(25, 74, 125); textSize = 18f
                typeface = Typeface.create("sans-serif", Typeface.BOLD)
            }
            val margin = 42f
            val maxWidth = pageW - margin * 2
            val lines = mutableListOf<Pair<String, Boolean>>()
            answerDraft.lines().forEach { raw ->
                if (raw.isBlank()) { lines.add("" to false); return@forEach }
                val isHeading = raw.startsWith("ChemStudy") || raw.startsWith("પ્રશ્ન ")
                val p = if (isHeading) headingPaint else paint
                var line = ""
                raw.split(Regex("\\s+")).forEach { word ->
                    val candidate = if (line.isEmpty()) word else "$line $word"
                    if (p.measureText(candidate) > maxWidth && line.isNotEmpty()) {
                        lines.add(line to isHeading); line = word
                    } else line = candidate
                }
                if (line.isNotEmpty()) lines.add(line to isHeading)
            }
            var pageNo = 1
            var page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create())
            var canvas = page.canvas
            var y = 52f
            lines.forEach { (line, heading) ->
                val p = if (heading) headingPaint else paint
                val step = if (heading) 27f else 19f
                if (y + step > pageH - 45) {
                    doc.finishPage(page); pageNo++
                    page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create())
                    canvas = page.canvas; y = 52f
                }
                canvas.drawText(line, margin, y, p)
                y += step
            }
            doc.finishPage(page)
            val file = File(getExternalFilesDir(null), "ChemStudy_Answers.pdf")
            FileOutputStream(file).use { doc.writeTo(it) }
            doc.close()
            val share = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, androidx.core.content.FileProvider.getUriForFile(
                    this@MainActivity, "$packageName.fileprovider", file
                ))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            // Open the saved PDF using Android's file viewer.
            val view = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(androidx.core.content.FileProvider.getUriForFile(
                    this@MainActivity, "$packageName.fileprovider", file
                ), "application/pdf")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            try { startActivity(view) } catch (_: Exception) {
                Toast.makeText(this, "PDF અહીં સેવ થઈ: ${file.absolutePath}", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            status.text = "PDF બનાવવામાં ભૂલ: ${e.message}"
        }
    }
}
