plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.chemstudy.pdfmaker"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.chemstudy.pdfmaker"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
dependencies {
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")\n    implementation("androidx.core:core:1.15.0")
}
